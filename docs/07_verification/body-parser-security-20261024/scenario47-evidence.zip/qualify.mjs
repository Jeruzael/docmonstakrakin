(async function qualify(){
 const fs=(await import('node:fs')).default,path=(await import('node:path')).default,{execFileSync,spawnSync}=await import('node:child_process'),{createHash}=await import('node:crypto');
 const root=path.dirname(process.argv[1]),dest=path.join(root,'candidate'),source='C:/Users/HomePC/.codex/worktrees/body-parser-security/docmonstakrakin-version-sync';
 const test='scripts/testControlledDocVersionSync.ts';fs.copyFileSync(path.join(source,test),path.join(dest,test));
 const src=fs.readFileSync(path.join(dest,test),'utf8').replace(/\r\n/g,'\n');
 const focused=src.slice(0,src.indexOf('// Scenario 1 & 2:'))+src.slice(src.indexOf('// Scenario 47 (RED-01):'),src.indexOf('// Helper: TypeScript AST Source-Contract'))+"\nawait browser.close();await vite.close();console.log(JSON.stringify({focused:'Scenario47 only',passed,failed}));if(failed)process.exitCode=1;";
 fs.writeFileSync(path.join(dest,'scripts/scenario47Focused.ts'),focused);
 const scripts=['scripts/scenario47Focused.ts',test,'scripts/testBodyParserSecurity.ts','scripts/testWorkspaceEnforcedServer.ts','scripts/testSecurityPerimeter.ts','server/security/testSecurityRegression.ts','server/security/testServerSecurityIntegration.ts'];
 const results=[];for(const script of scripts){
 const identity=execFileSync('git',['-C',dest,'rev-parse','HEAD','HEAD^{tree}'],{encoding:'utf8'}).trim();
 const start=new Date().toISOString();
 const run=spawnSync(process.execPath,['--import','tsx',script],{cwd:dest,encoding:'utf8',timeout:240000,env:{...process.env,PATH:path.dirname(process.execPath)+';'+process.env.PATH,GEMINI_API_KEY:''}});
 const entry={script,start,identity,testOverlaySha256:createHash('sha256').update(fs.readFileSync(path.join(dest,test))).digest('hex'),exit:run.status,error:run.error?.message};
 fs.writeFileSync(path.join(root,'qualification-'+path.basename(script)+'.log'),JSON.stringify(entry)+'\n'+(run.stdout||'')+'\n'+(run.stderr||''));
 results.push(entry);fs.writeFileSync(path.join(root,'qualification.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(entry));
 }
})();