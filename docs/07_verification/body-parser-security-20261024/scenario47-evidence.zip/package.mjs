(async function publishEvidence(){
 const fs=(await import('node:fs')).default,path=(await import('node:path')).default,{createHash}=await import('node:crypto');
 const root=path.dirname(process.argv[1]),dest=path.join(root,'publication');if(fs.existsSync(dest))throw Error('Already packaged');fs.mkdirSync(dest);
 const digest=b=>createHash('sha256').update(b).digest('hex'),manifest=[];
 for(const name of fs.readdirSync(root).filter(n=>/\.(json|log|mjs|md)$/.test(n))){
  const bytes=fs.readFileSync(path.join(root,name)),text=bytes.toString('utf8');
  const sanitized=text.replace(/([?&]token=)[^'"\s\\]+/g,'$1[REDACTED_DISPOSABLE_VITE_TOKEN]');
  fs.writeFileSync(path.join(dest,name),sanitized);
  manifest.push({name,rawSha256:digest(bytes),publishedSha256:digest(sanitized),redacted:sanitized!==text});
 }
 const original=path.resolve(root,'../ci/ci-40043247470-regression-failure.zip'),bytes=fs.readFileSync(original);
 if(digest(bytes)!=='9c4f2aa762980f9d426c07c003414bc5d7d13da83f3432e8962c6c969949356e')throw Error('Original artifact changed');
 fs.copyFileSync(original,path.join(dest,'ci-40043247470-regression-failure.zip'));
 manifest.push({name:'ci-40043247470-regression-failure.zip',rawSha256:digest(bytes),publishedSha256:digest(bytes),redacted:false});
 fs.writeFileSync(path.join(dest,'publication-manifest.json'),JSON.stringify(manifest,null,2));console.log(JSON.stringify({files:manifest.length,redacted:manifest.filter(x=>x.redacted).map(x=>x.name)}));
})();