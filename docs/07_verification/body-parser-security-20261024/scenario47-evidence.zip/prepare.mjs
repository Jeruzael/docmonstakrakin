import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/(.:)/,'$1'));
const source='C:/Users/HomePC/.codex/worktrees/body-parser-security/docmonstakrakin-version-sync';
const retained='C:/Users/HomePC/.codex/worktrees/campaign-report-truth/docmonstakrakin-version-sync/node_modules';
const fixtures=path.resolve(root,'../validation');
for(const [label,sha] of [['baseline','796adced2b0e9795b801c808359dee9c8839d7c4'],['candidate','8950479055a3d63689d5e73b29185bf8f6923242']]){
 const dest=path.join(root,label);if(fs.existsSync(dest))throw Error('Refuse existing clone '+dest);
 execFileSync('git',['clone','--no-hardlinks','--no-checkout',source,dest],{stdio:'inherit'});
 execFileSync('git',['-C',dest,'checkout','--detach',sha],{stdio:'inherit'});
 fs.cpSync(retained,path.join(dest,'node_modules'),{recursive:true});
 fs.cpSync(path.join(fixtures,label+'-fixture/node_modules/body-parser'),path.join(dest,'node_modules/body-parser'),{recursive:true});
 const git=(...a)=>execFileSync('git',['-C',dest,...a],{encoding:'utf8'}).trim();
 const lock=JSON.parse(fs.readFileSync(path.join(dest,'package-lock.json'),'utf8'));
 const mismatch=[];let checked=0;
 for(const [p,v] of Object.entries(lock.packages)){if(!p||!v.version)continue;const file=path.join(dest,p,'package.json');
 if(!fs.existsSync(file)){if(!v.optional)mismatch.push({path:p,expected:v.version,actual:'absent'});continue}
 const actual=JSON.parse(fs.readFileSync(file,'utf8')).version;checked++;if(actual!==v.version)mismatch.push({path:p,expected:v.version,actual});
 }
 const record={label,sha:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),node:process.version,retainedDependencySource:retained,installationQualification:false,checked,mismatch,tools:Object.fromEntries(['vite','playwright','typescript','tsx','express','body-parser'].map(p=>[p,JSON.parse(fs.readFileSync(path.join(dest,'node_modules',p,'package.json'),'utf8')).version]))};
 fs.writeFileSync(path.join(root,label+'-environment.json'),JSON.stringify(record,null,2));console.log(JSON.stringify(record));
}
