(async function diagnosticMain(){
const fs=(await import('node:fs')).default,path=(await import('node:path')).default,{execFileSync,spawnSync}=await import('node:child_process'),{createHash}=await import('node:crypto');
const root=path.dirname(process.argv[1]), modes=['ordinary','held','missing','invalid'], hash=s=>createHash('sha256').update(s).digest('hex'), matrix=[];
for(const label of ['baseline','candidate']){
 const dest=path.join(root,label), git=(...a)=>execFileSync('git',['-C',dest,...a],{encoding:'utf8'}).trim();
 git('config','core.longpaths','true');git('restore','--source=HEAD','--worktree','.');
 if(git('status','--porcelain'))throw Error('Dirty disposable checkout before instrumentation');
 const src=fs.readFileSync(path.join(dest,'scripts/testControlledDocVersionSync.ts'),'utf8').replace(/\r\n/g,'\n'),originalApp=fs.readFileSync(path.join(dest,'src/App.tsx'),'utf8');
 fs.writeFileSync(path.join(dest,'src/App.tsx'),originalApp.replace('  const isCanonicalMutationView =',`  console.debug('S47_STATE '+JSON.stringify({activeProjectId,projectLoading,loadError,certifiedSnapshotVersion,activeFloor,projectReady}));\n  const isCanonicalMutationView =`));
 for(const mode of modes){
 let prefix=src.slice(0,src.indexOf('// Scenario 1 & 2:'));
 prefix=prefix.replace('let passed = 0;',`const events:any[]=[];const started=performance.now();\nconst record=(event:string,data:any={})=>events.push({n:events.length,ms:Math.round((performance.now()-started)*100)/100,event,...data});\nasync function observe(page:Page,event:string){record(event,await page.evaluate(()=>({title:document.querySelector('header button')?.textContent,exportPresent:!!document.querySelector('#topbar-package-btn'),warning:document.querySelector('[data-testid="stale-snapshot-warning"]')?.textContent,scopes:[...document.querySelectorAll('[data-project-scope]')].map(e=>({id:e.getAttribute('data-project-scope'),busy:e.getAttribute('aria-busy'),inert:e.hasAttribute('inert')}))})));}\nlet passed = 0;`);
 prefix=prefix.replace('page.setDefaultTimeout(8000);',`page.setDefaultTimeout(8000);\n  record('browser',{version:browser.version()});\n  page.on('pageerror',e=>record('browser-error',{message:e.message}));\n  page.on('console',m=>{if(m.text().startsWith('S47_STATE '))record('app-state',JSON.parse(m.text().slice(10)));else if(m.type()==='error')record('console-error',{message:m.text()});});\n  page.on('request',r=>record('request',{method:r.method(),path:new URL(r.url()).pathname,mocked:new URL(r.url()).pathname.startsWith('/api/')}));\n  page.on('requestfailed',r=>record('request-failed',{path:new URL(r.url()).pathname,error:r.failure()?.errorText}));\n  page.on('response',r=>record('response',{path:new URL(r.url()).pathname,status:r.status()}));\n  await page.route('**/*',r=>{const host=new URL(r.request().url()).hostname;return host==='127.0.0.1'||host==='localhost'?r.continue():r.abort();});`);
 prefix=prefix.replace('await route.fulfill({ status, json: body }).catch(() => {});',`record('mock-fulfill',{path:url,method,status,stateVersion:body?.stateVersion});\n      await route.fulfill({ status, json: body }).catch(() => {});`);
 prefix=prefix.replace('  return {\n    page,',`  await observe(page,'harness-return-title-only');\n  return {\n    page,`);
 prefix=prefix.replace('      await page.close();',`      await observe(page,'before-close');\n      await page.close();`);
 let scenario=src.slice(src.indexOf('// Scenario 47 (RED-01):'),src.indexOf('// Helper: TypeScript AST Source-Contract'));
 scenario=scenario.replace("    // Starting fixture:",`    await observe(page,'initial-assertion-stage');\n    // Starting fixture:`);
 if(mode!=='ordinary'){
 scenario=scenario.replace('  const harness = await createHarness({ initialStateVersion: 120 });',`  let release!:()=>void;const gate=new Promise<void>(resolve=>{release=resolve;});\n  const harness=await createHarness({initialStateVersion:120,projectAResponseOverride:async()=>{record('snapshot-gate-enter');await gate;record('snapshot-gate-release');return ${mode==='invalid'?`{status:200,body:{...structuredClone(INITIAL_PROJECTS[0]),id:'PRJ-DOCMONSTAKRAKIN',name:'Invalid Snapshot',stateVersion:'invalid'}}`:'null'};}});`);
 scenario=scenario.replace('    // Starting fixture:',`    assert.match(await topBarProjectBtn.innerText(),/v120/);\n    assert.equal(await packageBtn.isVisible(),false,'Title is visible while complete snapshot is held');\n    record('original-initial-assertion-would-fail');\n    ${mode==='held'?`release();await packageBtn.waitFor({state:'visible'});await observe(page,'initial-snapshot-accepted');`:mode==='invalid'?`release();const begin=performance.now();await assert.rejects(packageBtn.waitFor({state:'visible'}),/Timeout 8000ms/);record('invalid-bounded-failure',{elapsedMs:performance.now()-begin});return;`:`const begin=performance.now();await assert.rejects(packageBtn.waitFor({state:'visible'}),/Timeout 8000ms/);record('missing-bounded-failure',{elapsedMs:performance.now()-begin});return;`}\n    // Starting fixture:`);
 scenario=scenario.replace('    await harness.close();','    release();\n    await harness.close();');
 }
 scenario=scenario.replace("    // Stale v120 snapshot",`    await observe(page,'save-ack-without-certification');\n    // Stale v120 snapshot`);
 scenario=scenario.replace("    // 7. Valid v121",`    await observe(page,'stale-snapshot-rejected');\n    // 7. Valid v121`);
 scenario=scenario.replace("    assert.ok(await packageBtn.isVisible(), 'Readiness restored on v121 complete snapshot recovery');",`    assert.ok(await packageBtn.isVisible(), 'Readiness restored on v121 complete snapshot recovery');\n    await observe(page,'current-complete-snapshot-accepted');`);
 const outfile=path.join(root,label+'-'+mode+'.json'),identity={label,mode,commit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),sourceTestSha256:hash(src),appOverlaySha256:hash(fs.readFileSync(path.join(dest,'src/App.tsx')))};
 const program=prefix+scenario+`\nawait browser.close();await vite.close();fs.writeFileSync(${JSON.stringify(outfile)},JSON.stringify({identity:${JSON.stringify(identity)},passed,failed,results,events},null,2));console.log(JSON.stringify({mode:${JSON.stringify(mode)},passed,failed}));if(failed)process.exitCode=1;`;
 fs.writeFileSync(path.join(dest,'scripts/scenario47Diagnostic.ts'),program);
 const run=spawnSync(process.execPath,['--import','tsx','scripts/scenario47Diagnostic.ts'],{cwd:dest,encoding:'utf8',timeout:120000,env:{...process.env,PATH:path.dirname(process.execPath)+';'+process.env.PATH}});
 fs.writeFileSync(path.join(root,label+'-'+mode+'.log'),(run.stdout||'')+(run.stderr||''));
 const entry={...identity,overlayTestSha256:hash(program),exit:run.status,error:run.error?.message};matrix.push(entry);console.log(JSON.stringify(entry));fs.writeFileSync(path.join(root,'matrix.json'),JSON.stringify(matrix,null,2));
 }
 fs.writeFileSync(path.join(dest,'src/App.tsx'),originalApp);
}
})();