# Scenario 47 bounded diagnosis — 2026-10-24
Authorization: operator Scenario 47 instruction; no merge/runtime changes.
Baseline master 796adced2b0e9795b801c808359dee9c8839d7c4; candidate 8950479055a3d63689d5e73b29185bf8f6923242.
Original run 40043247470 (attempt 1), artifact12540208323 retained; synthetic checkout6593a6599a4c6f78418206a2668b91769ec3c6b8/tree cb21f9d0a7f909cf8951cfa6fd2a378f056cf904.
Hypothesis: harness title-based return precedes complete snapshot acceptance; immediate isVisible does not wait.
Fixed diagnostic matrix: baseline and candidate, each one ordinary original Scenario47, one held-initial-snapshot red precondition then released lifecycle, one missing snapshot bounded readiness failure, one invalid snapshot bounded readiness failure. No retry-until-green.
Instrument disposable test copies only: API route request/response, browser error/failed request, DOM readiness projection and sequence timestamps. All API traffic intercepted; Vite serves real unchanged App assets. Do not access operator data.
Copied retained dependencies for matched local diagnostics only; record inventory and limitations, no SDK or installation. Actual fresh candidate qualification remains hosted CI.
Only if supported: scenario-specific visible Export readiness wait using inherited8000ms; preserve lifecycle assertions and remove stale retry sleep in favor of observable settled condition if supported. No global harness readiness.
Then focused corrected scenario and full50-scenario suite; security suites, final4CI jobs; preserve every outcome. Publish distinct signed test/evidence commit, keep86draft; renewed exactHEAD review. Keep85unchanged.
