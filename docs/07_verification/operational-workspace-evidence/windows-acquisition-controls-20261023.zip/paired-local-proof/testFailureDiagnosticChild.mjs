import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import cp from 'node:child_process';import {createRequire}from'node:module';import{fileURLToPath,pathToFileURL}from'node:url';
const inside=process.argv.includes('--inside'),source=inside?process.argv.at(-1):process.cwd();
if(!inside){
 const parent=fs.realpathSync.native(os.tmpdir()),root=fs.mkdtempSync(path.join(parent,'dmk-workspace-application-'));
 try{const boundary=createRequire(import.meta.url)(path.join(source,'server/security/workspaceAccess/privateBoundary.cjs'));boundary.capture(root,true);fs.writeFileSync(path.join(root,'.security','authority.sqlite'),'synthetic immutable diagnostic marker',{flag:'wx',mode:0o600});cp.execFileSync('icacls.exe',[path.join(root,'.security'),'/grant','*S-1-1-0:R'],{windowsHide:true,stdio:'pipe'});
  const run=cp.spawnSync(process.execPath,['--import',pathToFileURL(path.join(source,'node_modules/tsx/dist/loader.mjs')).href,fileURLToPath(import.meta.url),'--inside',source],{cwd:root,windowsHide:true,encoding:'utf8',timeout:20000});console.log(run.stdout);if(run.stderr)console.error(run.stderr);assert.equal(run.status,0);
 }finally{assert.equal(path.dirname(root),parent);assert.match(path.basename(root),/^dmk-workspace-application-/);fs.rmSync(root,{recursive:true,maxRetries:10,retryDelay:100})}
}else{
 const root=process.cwd(),marker=path.join(root,'.security','authority.sqlite'),bytes=fs.readFileSync(marker),before=fs.statSync(marker),beforeAcl=cp.execFileSync('icacls.exe',[path.join(root,'.security')],{encoding:'utf8',windowsHide:true});
 const api=await import(pathToFileURL(path.join(source,'scripts/fixtures/workspaceAdmissionDiagnostics.ts')).href);assert.equal(typeof api.installWorkspaceAdmissionFailureDiagnostics,'function');const undo=api.installWorkspaceAdmissionFailureDiagnostics(),oldError=console.error,lines=[];console.error=(...args)=>lines.push(args.join(' '));
 try{const boundary=createRequire(import.meta.url)(path.join(source,'server/security/workspaceAccess/privateBoundary.cjs'));
  let caught;try{boundary.capture(root,false)}catch(error){caught=error}
  assert.equal(caught?.code,'WORKSPACE_PERMISSIONS_INVALID');const failure=JSON.parse(lines.find(line=>line.startsWith('WORKSPACE_STRICT_ADMISSION_FAILURE ')).slice('WORKSPACE_STRICT_ADMISSION_FAILURE '.length));assert.equal(failure.status,3);assert.match(lines.join('\n'),/WORKSPACE_STRICT_ADMISSION_CONTEXT /);assert.doesNotMatch(lines.join('\n'),/synthetic immutable diagnostic marker/);assert.deepEqual(fs.readFileSync(marker),bytes);const after=fs.statSync(marker);assert.equal(after.ino,before.ino);assert.equal(after.mtimeMs,before.mtimeMs);assert.equal(cp.execFileSync('icacls.exe',[path.join(root,'.security')],{encoding:'utf8',windowsHide:true}),beforeAcl);
 }finally{console.error=oldError;undo()}
 console.log('PASS genuine strict boundary rejects foreign ACE, retains PowerShell status3 and authority bytes/ACL while reporting bounded read-only context');
}
