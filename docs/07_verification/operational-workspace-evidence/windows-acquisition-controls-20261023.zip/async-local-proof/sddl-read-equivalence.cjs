'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process'),crypto=require('node:crypto');
const parent=fs.realpathSync.native(os.tmpdir()),root=fs.mkdtempSync(path.join(parent,'dmk-sddl-equivalence-'));
try {
  const file=path.join(root,'inert.txt');fs.writeFileSync(file,Buffer.from([0]),{flag:'wx',mode:0o600});
  const literal=value=>"'"+value.replaceAll("'","''")+"'";
  const code="$ErrorActionPreference='Stop';$sections=[System.Security.AccessControl.AccessControlSections]::Owner -bor [System.Security.AccessControl.AccessControlSections]::Group -bor [System.Security.AccessControl.AccessControlSections]::Access;$out=@();"+
    [['directory',root,'Directory'],['file',file,'File']].map(([kind,target,type])=>
      "$old=Get-Acl -LiteralPath "+literal(target)+";$new=[System.IO."+type+"]::GetAccessControl("+literal(target)+");$a=$old.GetSecurityDescriptorSddlForm($sections);$b=$new.GetSecurityDescriptorSddlForm($sections);$out+=[ordered]@{kind='"+kind+"';legacy=$a;direct=$b;equal=($a -ceq $b);protectedEqual=($old.AreAccessRulesProtected -eq $new.AreAccessRulesProtected)};").join('')+
    '$out|ConvertTo-Json -Compress';
  const raw=cp.execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(code,'utf16le').toString('base64')],{encoding:'utf8',windowsHide:true,timeout:4000,stdio:['ignore','pipe','pipe'],env:{...process.env,PSModulePath:path.join(process.env.WINDIR,'System32/WindowsPowerShell/v1.0/Modules')}}).trim();
  const records=JSON.parse(raw);if(records.length!==2||records.some(r=>!r.equal||!r.protectedEqual))throw Error('DESCRIPTOR_EQUIVALENCE_FAILED');
  if(!fs.readFileSync(file).equals(Buffer.from([0])))throw Error('INERT_BYTES_CHANGED');
  console.log(JSON.stringify({kind:'LOCAL_READ_ONLY_DESCRIPTOR_EQUIVALENCE_NOT_HOSTED_PROOF',records,rawSHA256:crypto.createHash('sha256').update(raw).digest('hex'),cases:2,aclMutations:0}));
}finally{if(path.dirname(root)!==parent||!/^dmk-sddl-equivalence-/.test(path.basename(root))||fs.lstatSync(root).isSymbolicLink())throw Error('CLEANUP_REJECTED');fs.rmSync(root,{recursive:true});}
