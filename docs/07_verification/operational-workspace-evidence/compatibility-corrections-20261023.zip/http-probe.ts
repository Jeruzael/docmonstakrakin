import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {startIsolatedVite} from '../scripts/fixtures/isolatedVite.ts';
const root=process.cwd(), outside=path.resolve(root,'../outside-http-fixture.txt');
fs.writeFileSync(outside,'SYNTHETIC_OUTSIDE_FIXTURE');
const privateRoot=path.join(root,'.security');fs.mkdirSync(privateRoot,{recursive:true});fs.writeFileSync(path.join(privateRoot,'fixture.sqlite'),'SYNTHETIC_PRIVATE_FIXTURE');
const vite=await startIsolatedVite(root);let failed=0;
async function check(url:string,status:number){const response=await fetch(new URL(url,vite.resolvedUrls!.local[0]));const body=await response.text();console.log(JSON.stringify({url,status:response.status,expected:status,cacheDir:vite.config.cacheDir}));if(response.status!==status)failed++;if(status===403)assert(!body.includes('SYNTHETIC_'));return body;}
try{await check('/@vite/client',200);const entry=await check('/src/main.tsx',200);const dependencies=[...entry.matchAll(/(?:from\s*|import\s*)["']([^"']+)["']/g)].map(match=>match[1]).filter(url=>url.startsWith('/@fs/')||url.startsWith('/runtime/dmk-vite-fixture-'));assert(dependencies.length>0);for(const url of dependencies)await check(url,200);await check('/@fs/'+outside.replaceAll('\\','/'),403);await check('/.security/fixture.sqlite?raw',403);await check('/@fs/'+path.join(privateRoot,'fixture.sqlite').replaceAll('\\','/'),403);}finally{await vite.close();}
console.log('HTTP_PROBE_FAILURES '+failed);if(failed)process.exitCode=1;
