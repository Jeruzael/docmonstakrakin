$ErrorActionPreference='Stop'
$parseErrors=$null;$parseTokens=$null
$tree=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path (Get-Location) 'scripts/runWindowsPrivateQualification.ps1'),[ref]$parseTokens,[ref]$parseErrors)
if($parseErrors.Count){throw 'SCRIPT_PARSE_FAILED'}
$function=$tree.Find({param($node)$node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'New-PrivateProbeDacl'},$true)
if(-not$function){throw 'EXPECTED_PRIVATE_PROBE_DACL_BUILDER_MISSING'}
. ([ScriptBlock]::Create($function.Extent.Text))
$identity=[System.Security.Principal.WindowsIdentity]::GetCurrent();$sid=$identity.User.Value;$identity.Dispose()
$rootParent=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
$root=Join-Path $rootParent ('dmk-owner-dacl-test-'+[Guid]::NewGuid().ToString('N'))
$created=$false
try {
  New-Item -ItemType Directory -Path $root -ErrorAction Stop|Out-Null;$created=$true
  $ownerBefore=(Get-Acl -LiteralPath $root).GetOwner([Security.Principal.SecurityIdentifier]).Value
  $adversarial=[Security.AccessControl.DirectorySecurity]::new();$adversarial.SetAccessRuleProtection($true,$false)
  foreach($fixtureSid in @($sid,'S-1-5-18','S-1-5-32-544')){
    $rule=[Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($fixtureSid),[Security.AccessControl.FileSystemRights]::FullControl,([Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit),[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow)
    $adversarial.AddAccessRule($rule)
  }
  Set-Acl -LiteralPath $root -AclObject $adversarial
  $file=Join-Path $root 'synthetic.txt';$stream=[IO.File]::Open($file,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$stream.WriteByte(1)}finally{$stream.Dispose()}
  if(@((Get-Acl -LiteralPath $root).GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])).Count -ne 3){throw 'ADVERSARIAL_INITIAL_DACL_NOT_ESTABLISHED'}
  $replacement=New-PrivateProbeDacl $sid
  if(-not$replacement.AreAccessRulesProtected){throw 'BUILDER_NOT_PROTECTED'}
  [IO.FileSystemAclExtensions]::SetAccessControl([IO.DirectoryInfo]::new($root),$replacement)
  $after=Get-Acl -LiteralPath $root
  if($after.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $ownerBefore){throw 'OWNER_WAS_CHANGED'}
  foreach($item in @($root,$file)){
    $acl=Get-Acl -LiteralPath $item;$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
    if($rules.Count -ne 1 -or $rules[0].IdentityReference.Value -ne $sid -or $rules[0].AccessControlType -ne 'Allow' -or [long]$rules[0].FileSystemRights -ne [long][Security.AccessControl.FileSystemRights]::FullControl){throw 'NONEMPTY_PROBE_EXACT_DACL_FAILED'}
  }
  if([IO.File]::ReadAllBytes($file)[0] -ne 1){throw 'SYNTHETIC_CONTENT_CHANGED'}
  Write-Output 'PASS exact protected single-user DACL on nonempty newly created adversarial directory; owner and synthetic content preserved'
}finally{
  if($created){
    $absolute=[IO.Path]::GetFullPath($root)
    if([IO.Path]::GetDirectoryName($absolute) -ne $rootParent -or [IO.Path]::GetFileName($absolute) -notmatch '^dmk-owner-dacl-test-[a-f0-9]{32}$' -or ((Get-Item -LiteralPath $absolute).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'UNSAFE_TEST_CLEANUP'}
    Remove-Item -LiteralPath $absolute -Recurse -Force
  }
}
