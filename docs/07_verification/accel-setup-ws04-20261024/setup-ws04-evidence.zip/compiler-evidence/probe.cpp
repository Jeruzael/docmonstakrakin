#include <windows.h>
#include <stdio.h>
int main(){DWORD value=GetCurrentProcessId();printf("SDK_NATIVE_PROBE %lu\n",value);return value?0:1;}
