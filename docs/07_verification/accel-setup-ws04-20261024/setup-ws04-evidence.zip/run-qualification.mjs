import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url));
const checkout=process.env.DMK_QUALIFICATION_CHECKOUT || path.resolve(root,'../..');
const phase=process.argv[2];
const out=path.join(root,(process.env.DMK_QUALIFICATION_PROFILE||'')+phase+'-evidence');
fs.mkdirSync(out);
const records=[];
function run(label,exe,args,cwd=checkout,timeout=600000){
 const started=new Date().toISOString();
 const r=spawnSync(exe,args,{cwd,encoding:'utf8',windowsHide:true,timeout,maxBuffer:16*1024*1024});
 fs.writeFileSync(path.join(out,label+'.stdout.log'),r.stdout||'');fs.writeFileSync(path.join(out,label+'.stderr.log'),r.stderr||'');
 const record={label,exe,args,started,finished:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?.code};
 records.push(record);fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(records,null,2)+'\n');
 console.log(JSON.stringify(record));
 if(r.status!==0)throw Error('QUALIFICATION_FAILED:'+label);
 return r.stdout;
}
const node=process.execPath,npm=process.env.NPMCLI;
function lifecycleInventory(bunCheckout){
 const file=path.join(out,'lifecycle-inventory.combined.log');
 const fd=fs.openSync(file,'wx');let result;
 try{result=spawnSync(node,[npm,'exec','--yes','--package=bun@1.4.2','--','bun','pm','untrusted'],{cwd:bunCheckout,windowsHide:true,timeout:60000,stdio:['ignore',fd,fd]});}finally{fs.closeSync(fd);}
 if(result.status!==0)throw Error('BUN_INVENTORY_ACQUISITION_FAILED');
 const guard=spawnSync(node,['scripts/lib/bunLifecycleInventory.mjs'],{cwd:bunCheckout,input:fs.readFileSync(file),encoding:'utf8'});
 fs.writeFileSync(path.join(out,'lifecycle-guard.log'),(guard.stdout||'')+(guard.stderr||''));
 console.log(JSON.stringify({label:'lifecycle-guard',status:guard.status}));
 if(guard.status!==0)throw Error('BUN_LIFECYCLE_GUARD_FAILED');
}
if(phase==='compiler'){
 fs.writeFileSync(path.join(out,'probe.cpp'),'#include <windows.h>\n#include <stdio.h>\nint main(){DWORD value=GetCurrentProcessId();printf("SDK_NATIVE_PROBE %lu\\n",value);return value?0:1;}\n');
 const xml='<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><ItemGroup Label="ProjectConfigurations"><ProjectConfiguration Include="Release|x64"><Configuration>Release</Configuration><Platform>x64</Platform></ProjectConfiguration></ItemGroup><PropertyGroup Label="Globals"><WindowsTargetPlatformVersion>10.0.26100.0</WindowsTargetPlatformVersion></PropertyGroup><Import Project="$(VCTargetsPath)Microsoft.Cpp.Default.props"/><PropertyGroup Condition="\'$(Configuration)|$(Platform)\'==\'Release|x64\'" Label="Configuration"><ConfigurationType>Application</ConfigurationType><PlatformToolset>v145</PlatformToolset></PropertyGroup><Import Project="$(VCTargetsPath)Microsoft.Cpp.props"/><ItemGroup><ClCompile Include="probe.cpp"/></ItemGroup><Import Project="$(VCTargetsPath)Microsoft.Cpp.targets"/></Project>';
 fs.writeFileSync(path.join(out,'probe.vcxproj'),xml);
 run('cl-probe','cl.exe',['/nologo','/Bv','probe.cpp','/Fe:direct-probe.exe'],out);
 run('direct-probe',path.join(out,'direct-probe.exe'),[],out);
 run('msbuild-probe','MSBuild.exe',['probe.vcxproj','/p:Configuration=Release','/p:Platform=x64','/verbosity:minimal','/nologo'],out);
 run('msbuild-binary',path.join(out,'x64/Release/probe.exe'),[],out);
}else if(phase==='npm'){
 if(fs.existsSync(path.join(checkout,'node_modules')))throw Error('DEPENDENCIES_MUST_START_ABSENT');
 run('node-version',node,['--version']);run('npm-version',node,[npm,'--version']);
 run('install',node,[npm,'ci','--foreground-scripts','--registry=https://registry.npmjs.org']);
 run('audit',node,[npm,'audit','--json','--registry=https://registry.npmjs.org']);
 run('provenance',node,[npm,'ls','vite','source-map-js','better-sqlite3','argon2','express','body-parser','--all','--json']);
}else if(phase==='npm-checks'){
 for(const file of ['testSyntheticSecurityFoundations','testSyntheticStorePaths','testWorkspacePrivateDirectory','testWorkspaceStore','testWorkspaceApplication','testWorkspaceTls','testWorkspaceBackup','testBodyParserSecurity'])run(file,node,['--import','tsx','scripts/'+file+'.ts']);
 for(const name of ['wbs:check','lint','build'])run(name.replace(':','-'),node,[npm,'run',name]);
}else if(phase==='bun'){
 const bunCheckout=process.env.DMK_BUN_CHECKOUT || path.join(root,'bun-checkout');
 if(fs.existsSync(path.join(bunCheckout,'node_modules')))throw Error('BUN_DEPENDENCIES_MUST_START_ABSENT');
 run('bun-dist',node,[npm,'view','bun@1.4.2','dist','--json','--registry=https://registry.npmjs.org'],bunCheckout);
 const exec=['exec','--yes','--package=bun@1.4.2','--','bun'];
 run('bun-version',node,[npm,...exec,'--version'],bunCheckout);
 run('bun-revision',node,[npm,...exec,'--revision'],bunCheckout);
 run('install',node,[npm,...exec,'install','--frozen-lockfile','--cache-dir',path.join(root,(process.env.DMK_QUALIFICATION_PROFILE||'')+'bun-cache')],bunCheckout);
 run('audit',node,[npm,...exec,'audit','--json'],bunCheckout);
 lifecycleInventory(bunCheckout);
 run('provenance',node,[npm,'ls','better-sqlite3','argon2','express','body-parser','--all','--json'],bunCheckout);
}else if(phase==='bun-followup'){
 const bunCheckout=process.env.DMK_BUN_CHECKOUT || path.join(root,'bun-checkout');
 lifecycleInventory(bunCheckout);
 run('provenance',node,[npm,'ls','better-sqlite3','argon2','express','body-parser','--all','--json'],bunCheckout);}else if(phase==='bun-checks'){
 const bunCheckout=process.env.DMK_BUN_CHECKOUT || path.join(root,'bun-checkout');
 for(const file of ['testSyntheticSecurityFoundations','testSyntheticStorePaths','testWorkspacePrivateDirectory','testWorkspaceStore','testWorkspaceApplication','testWorkspaceTls','testWorkspaceBackup','testBodyParserSecurity'])run(file,node,['--import','tsx','scripts/'+file+'.ts'],bunCheckout);
 for(const name of ['wbs:check','lint','build'])run(name.replace(':','-'),node,[npm,'run',name],bunCheckout);}else throw Error('UNKNOWN_PHASE');