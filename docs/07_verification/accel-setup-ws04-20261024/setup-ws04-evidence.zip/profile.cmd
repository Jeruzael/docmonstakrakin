@echo off
set "VSROOT=C:\Program Files\Microsoft Visual Studio\18\Community"
set "SDKROOT=%~dp0private-sdk"
set "NODEDIR=C:\Users\HomePC\AppData\Local\Temp\dmk-node-22.23.3-ab7bc72893cb47a987f31af733436578"
set "NPMCLI=C:\nvm4w\nodejs\node_modules\npm\bin\npm-cli.js"
set "RUNROOT=%~dp0"
set "VSCMD_DEBUG="
call "%VSROOT%\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64 -winsdk=none
if errorlevel 1 exit /b 1
set "WindowsSdkDir=%SDKROOT%\"
set "WindowsSDKVersion=10.0.26100.0\"
set "WindowsSDKLibVersion=10.0.26100.0\"
set "WindowsSdkDir_10=%SDKROOT%\"
set "UniversalCRTSdkDir_10=%SDKROOT%\"
set "UniversalCRTSdkDir=%SDKROOT%\"
set "UCRTContentRoot=%SDKROOT%\"
set "UniversalCRTVersion=10.0.26100.0"
set "UCRTVersion=10.0.26100.0"
set "WindowsSdkBinPath=%SDKROOT%\bin\"
set "WindowsSdkVerBinPath=%SDKROOT%\bin\10.0.26100.0\"
set "INCLUDE=%SDKROOT%\Include\10.0.26100.0\ucrt;%SDKROOT%\Include\10.0.26100.0\um;%SDKROOT%\Include\10.0.26100.0\shared;%SDKROOT%\Include\10.0.26100.0\winrt;%INCLUDE%"
set "LIB=%SDKROOT%\Lib\10.0.26100.0\ucrt\x64;%SDKROOT%\Lib\10.0.26100.0\um\x64;%LIB%"
set "PATH=%NODEDIR%;%SDKROOT%\bin\10.0.26100.0\x64;%PATH%"
set "NPM_CONFIG_USERCONFIG=%RUNROOT%empty.npmrc"
set "NPM_CONFIG_CACHE=%RUNROOT%npm-cache"
set "npm_package_config_node_gyp_devdir=%RUNROOT%node-headers"
"%NODEDIR%\node.exe" "%RUNROOT%run-qualification.mjs" %*
exit /b %errorlevel%