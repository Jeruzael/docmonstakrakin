from pathlib import Path
import json,hashlib,re,zipfile,subprocess
r=Path(__file__).parent
repo=Path('C:/Users/HomePC/.codex/worktrees/body-parser-security/docmonstakrakin-version-sync')
sha=lambda b:hashlib.sha256(b).hexdigest()
before=subprocess.check_output(['git','show','HEAD:scripts/testControlledDocVersionSync.ts'],cwd=repo).decode().replace('\r\n','\n')
after=(repo/'scripts/testControlledDocVersionSync.ts').read_text(encoding='utf-8').replace('\r\n','\n')
a=before.index('// Scenario 44 ('); b=before.index('// Scenario 45 (')
aa=after.index('// Scenario 44 ('); bb=after.index('// Scenario 45 (')
assert before[:a]==after[:aa] and before[b:]==after[bb:], 'Outside Scenario44 changed'
assert len(re.findall(r'await test\(',after))==50
assert sha((repo/'scripts/testControlledDocVersionSync.ts').read_bytes())=='02c996df249a72db911d53725a5d3cfc1ad5da6f2dbe34ccc1ac261adad91283'
qualification=json.loads((r/'qualification.json').read_text(encoding='utf-8'));assert len(qualification)==9 and all(x['exit']==0 for x in qualification)
failure=(r/'ci-40050545096-regression-failure.zip').read_bytes();assert sha(failure)=='db30db619014261c64a26de5a432cb780e431c8a12a9f3cf15913fe95cb08fb6'
publication=r/'publication';publication.mkdir(exist_ok=False)
manifest=[]
for f in sorted(r.iterdir()):
 if not f.is_file() or f.suffix not in ['.md','.json','.mjs','.py','.log','.zip']:continue
 raw=f.read_bytes();published=raw
 if f.suffix!='.zip':
  text=raw.decode('utf-8')
  text=re.sub(r'([?&]token=)[A-Za-z0-9_\-]+',r'\1REDACTED_EPHEMERAL_VITE_TOKEN',text)
  published=text.encode('utf-8')
 (publication/f.name).write_bytes(published)
 manifest.append({'file':f.name,'bytes':len(published),'rawSha256':sha(raw),'publishedSha256':sha(published),'redacted':raw!=published})
(publication/'publication-manifest.json').write_text(json.dumps(manifest,indent=2))
for f in publication.iterdir():
 if f.suffix=='.zip':continue
 content=f.read_text(encoding='utf-8')
 assert not re.search(r'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----)',content),f'Sensitive marker in {f.name}'
 assert not re.search(r'[?&]token=(?!REDACTED_EPHEMERAL_VITE_TOKEN)[A-Za-z0-9_\-]+',content),f'Unredacted ephemeral token in {f.name}'
destination=repo/'docs/07_verification/scenario44-readiness-20261024/evidence.zip';destination.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(publication.iterdir()):z.write(f,f.name)
with zipfile.ZipFile(destination) as z:
 assert z.testzip() is None
 assert z.read('ci-40050545096-regression-failure.zip')==failure
result={'path':str(destination),'bytes':destination.stat().st_size,'sha256':sha(destination.read_bytes()),'members':len(list(publication.iterdir())),'sourceScope':'Only Scenario44 modified; other49 entries unchanged','redactedFiles':[x['file'] for x in manifest if x['redacted']]}
(r/'archive-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
