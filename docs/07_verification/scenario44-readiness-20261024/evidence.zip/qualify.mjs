import fs from 'node:fs';import path from 'node:path';import {execFileSync,spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const root=path.dirname(process.argv[1]),dest=path.join(root,'merged'),source='C:/Users/HomePC/.codex/worktrees/body-parser-security/docmonstakrakin-version-sync';
const git=(...a)=>execFileSync('git',['-C',dest,...a],{encoding:'utf8'}).trim();
if(git('diff','--','src','server'))throw Error('Runtime diagnostic overlay still present');
const test='scripts/testControlledDocVersionSync.ts';fs.copyFileSync(path.join(source,test),path.join(dest,test));
const src=fs.readFileSync(path.join(dest,test),'utf8'),hash=s=>createHash('sha256').update(s).digest('hex');
const focused=src.replace('  if (releaseOnly &&',`  if(!/^Scenario (?:44|47|48|49|50)(?:\\s|:)/.test(name)){skipped++;return;}\n  if (releaseOnly &&`);
fs.writeFileSync(path.join(dest,'scripts/scenario44Focused.ts'),focused);
const commands=[['--import','tsx','scripts/scenario44Focused.ts'],['--import','tsx',test],...['scripts/testBodyParserSecurity.ts','scripts/testWorkspaceEnforcedServer.ts','scripts/testSecurityPerimeter.ts','server/security/testSecurityRegression.ts','server/security/testServerSecurityIntegration.ts','scripts/renderWbs.ts'].map(s=>['--import','tsx',s,...(s.endsWith('renderWbs.ts')?['--check']:[])]),['node_modules/typescript/bin/tsc','--noEmit']];
const results=[];for(const args of commands){const name=path.basename(args.includes('--import')?args[2]:args[0]),entry={command:[process.execPath,...args],start:new Date().toISOString(),commit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),testOverlaySha256:hash(src),runtimeSourceUnchanged:!git('diff','--','src','server')};
 const run=spawnSync(process.execPath,args,{cwd:dest,encoding:'utf8',timeout:240000,env:{...process.env,PATH:path.dirname(process.execPath)+';'+process.env.PATH,GEMINI_API_KEY:''}});
 Object.assign(entry,{end:new Date().toISOString(),exit:run.status,error:run.error?.message});fs.writeFileSync(path.join(root,'qualification-'+name+'.log'),JSON.stringify(entry)+'\n'+(run.stdout||'')+'\n'+(run.stderr||''));results.push(entry);fs.writeFileSync(path.join(root,'qualification.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(entry));
}
