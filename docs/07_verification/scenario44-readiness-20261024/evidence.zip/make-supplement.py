from pathlib import Path
r=Path(__file__).parent
s=(r/'diagnose.mjs').read_text()
a=s.index('const cases='); b=s.index('\nfunction replaceOnce',a)
s=s[:a]+"const cases=[{label:'reviewed',mode:'old-held',scenario:44},{label:'merged',mode:'existing-held',scenario:49}];"+s[b:]
s=s.replace("id=label+'-'+scenario+'-'+mode", "id=label+'-'+scenario+'-'+mode+'-supplement'")
s=s.replace("'matrix.json'", "'supplement-matrix.json'")
s=s.replace("    await page.getByText('INCOMPLETE (SERVER-REPORTED)', {exact: true}).waitFor();", '    await page.locator(\'[data-testid="controlled-docs-workspace"]\').waitFor();')
s=s.replace("    await heldBarrier(page,page.getByText('INCOMPLETE (SERVER-REPORTED)', {exact:true}));", '    await heldBarrier(page,page.locator(\'[data-testid="controlled-docs-workspace"]\'));')
# Escape the embedded double quotes in the generated JavaScript double-quoted anchor.
s=s.replace('data-testid="controlled-docs-workspace"','data-testid=\\"controlled-docs-workspace\\"')
(r/'diagnose-supplement.mjs').write_text(s)
