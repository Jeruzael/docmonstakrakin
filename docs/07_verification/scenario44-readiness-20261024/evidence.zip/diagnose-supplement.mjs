import fs from 'node:fs';import path from 'node:path';import {execFileSync,spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const root=path.dirname(process.argv[1]),hash=s=>createHash('sha256').update(s).digest('hex'),matrix=[];
const cases=[{label:'reviewed',mode:'old-held',scenario:44},{label:'merged',mode:'existing-held',scenario:49}];
function replaceOnce(s,a,b){if(s.split(a).length!==2)throw Error('Expected unique anchor: '+a);return s.replace(a,b);}
for(const label of ['reviewed','merged']){
 const dest=path.join(root,label),git=(...a)=>execFileSync('git',['-C',dest,...a],{encoding:'utf8'}).trim();
 const src=fs.readFileSync(path.join(dest,'scripts/testControlledDocVersionSync.ts'),'utf8');
 const appPath=path.join(dest,'src/App.tsx'),loaderPath=path.join(dest,'src/data/projectWorkspace.ts');
 const originalApp=fs.readFileSync(appPath,'utf8'),originalLoader=fs.readFileSync(loaderPath,'utf8');
 let app=replaceOnce(originalApp,'  const isCanonicalMutationView =',`  console.debug('S44_STATE '+JSON.stringify({activeProjectId,projectLoading,loadError,certifiedSnapshotVersion:certifiedSnapshotVersion??null,activeFloor,projectReady}));\n  const isCanonicalMutationView =`);
 app=replaceOnce(app,'      onCommit:data=>{',`      onCommit:data=>{console.debug('S44_COMMIT '+JSON.stringify({id:data.project.id,stateVersion:data.project.stateVersion}));`);
 app=replaceOnce(app,'        acceptedCanonicalSnapshotVersionsRef.current[data.project.id] = incomingVersion;',`        acceptedCanonicalSnapshotVersionsRef.current[data.project.id] = incomingVersion;\n        console.debug('S44_ACCEPT '+JSON.stringify({id:data.project.id,version:incomingVersion,effectiveFloor}));`);
 const loader=replaceOnce(originalLoader,'          return [key,value];',`          console.debug('S44_VALID '+JSON.stringify({projectId,key,version:key==='project'?value.stateVersion:null}));\n          return [key,value];`);
 fs.writeFileSync(appPath,app);fs.writeFileSync(loaderPath,loader);
 try{for(const item of cases.filter(c=>c.label===label)){
  const {mode,scenario}=item, id=label+'-'+scenario+'-'+mode+'-supplement';
  let program=replaceOnce(src,'let passed = 0;',`const events:any[]=[];const started=performance.now();let releaseInitial!:()=>void;const initialGate=new Promise<void>(r=>releaseInitial=r);\nconst record=(event:string,data:any={})=>events.push({n:events.length,ms:Math.round((performance.now()-started)*100)/100,event,...data});\nasync function observe(page:Page,event:string){record(event,await page.evaluate(()=>({title:document.querySelector('header button')?.textContent,exportPresent:!!document.querySelector('#topbar-package-btn'),warning:document.querySelector('[data-testid="stale-snapshot-warning"]')?.textContent,main:document.querySelector('main')?.textContent?.slice(0,1200),scopes:[...document.querySelectorAll('[data-project-scope]')].map(e=>({id:e.getAttribute('data-project-scope'),busy:e.getAttribute('aria-busy'),inert:e.hasAttribute('inert')}))})));}\nasync function heldBarrier(page:Page,locator:any){await observe(page,'barrier-start');let settled=false;const waiting=locator.waitFor({state:'visible'}).then(()=>{settled=true;});await page.evaluate(()=>new Promise<void>(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r()))));assert.equal(settled,false,'Readiness consumer remains pending while snapshot held');record('barrier-pending');releaseInitial();await waiting;await observe(page,'barrier-completed');}\nlet passed = 0;`);
  program=replaceOnce(program,'  if (releaseOnly &&',`  if(!name.startsWith('Scenario ${scenario}${scenario===50?':':' ('}')) {skipped++;return;}\n  if (releaseOnly &&`);
  program=replaceOnce(program,'  page.setDefaultTimeout(8000);',`  page.setDefaultTimeout(8000);\n  record('browser',{version:browser.version()});\n  page.on('pageerror',e=>record('browser-error',{message:e.message}));\n  page.on('console',m=>{const text=m.text();const match=/^S44_(STATE|COMMIT|ACCEPT|VALID) (.*)$/.exec(text);if(match)record(match[1],JSON.parse(match[2]));else if(m.type()==='error')record('console-error',{message:text});});\n  page.on('request',r=>record('request',{method:r.method(),path:new URL(r.url()).pathname,mocked:new URL(r.url()).pathname.startsWith('/api/')}));\n  page.on('requestfailed',r=>record('request-failed',{path:new URL(r.url()).pathname,error:r.failure()?.errorText}));\n  page.on('response',r=>record('response',{path:new URL(r.url()).pathname,status:r.status()}));\n  await page.route('**/*',r=>{const host=new URL(r.request().url()).hostname;return host==='127.0.0.1'||host==='localhost'?r.continue():r.abort();});`);
  program=replaceOnce(program,'      await route.fulfill({ status, json: body }).catch(() => {});',`      record('mock-fulfill',{path:url,method,status,stateVersion:body?.stateVersion,list:Array.isArray(body)&&url==='/api/projects'?body.map(p=>({id:p.id,name:p.name,stateVersion:p.stateVersion})):undefined});\n      await route.fulfill({ status, json: body }).catch(() => {});`);
  program=replaceOnce(program,'      projectAFetchCount++;',`      projectAFetchCount++;\n      if(projectAFetchCount===1){record('initial-snapshot-held');await initialGate;record('initial-snapshot-released');${mode==='invalid'?`return send({...projectAData,stateVersion:'invalid'});`:''}}`);
  program=replaceOnce(program,'  return {\n    page,',`  await observe(page,'harness-return-title-only');\n  return {\n    page,`);
  program=replaceOnce(program,'      await page.close();',`      await observe(page,'before-close');releaseInitial();\n      await page.close();`);
  let scenarioStart=program.indexOf(`await test('Scenario ${scenario}${scenario===50?':':' ('}`),next=program.indexOf("await test('Scenario",scenarioStart+1);
  if(next<0)next=program.indexOf('await browser.close();',scenarioStart);
  let section=program.slice(scenarioStart,next);
  if(scenario===44){
   const anchor="    assert.ok(await packageBtn.isVisible(), 'Export package button visible when projectReady is true');";
   let extra="    await observe(page,'initial-assertion-point');\n";
   if(mode==='fixed-held')extra+="    await heldBarrier(page,packageBtn);\n";
   if(mode==='missing'||mode==='invalid')extra+=`${mode==='invalid'?'    releaseInitial();\n':''}    const begin=performance.now();await assert.rejects(packageBtn.waitFor({state:'visible'}),/Timeout 8000ms/);record('${mode}-bounded-failure',{elapsedMs:performance.now()-begin});return;\n`;
   section=replaceOnce(section,anchor,extra+anchor);
   section=replaceOnce(section,'    // List advances A to v121',"    await observe(page,'initial-certified-120');\n    // List advances A to v121");
   section=replaceOnce(section,'    // Stale snapshot retry with v120',"    await observe(page,'list121-invalidates120');\n    // Stale snapshot retry with v120");
   section=replaceOnce(section,'    // Fresh snapshot retry with v121',"    await observe(page,'stale120-rejected');\n    // Fresh snapshot retry with v121");
   section=replaceOnce(section,"    assert.match(await topBarProjectBtn.innerText(), /Fresh Snapshot v121/);","    assert.match(await topBarProjectBtn.innerText(), /Fresh Snapshot v121/);\n    await observe(page,'current121-restored');");
  }else if(scenario===49){section=replaceOnce(section,"    await page.locator('[data-testid=\"controlled-docs-workspace\"]').waitFor();","    await heldBarrier(page,page.locator('[data-testid=\"controlled-docs-workspace\"]'));");}
  else{const anchor=scenario===47?"    await packageBtn.waitFor({ state: 'visible' });":"    await packageBtn.waitFor({state: 'visible'});";section=replaceOnce(section,anchor,'    await heldBarrier(page,packageBtn);');}
  program=program.slice(0,scenarioStart)+section+program.slice(next);
  const identity={...item,commit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),testSourceSha256:hash(src),appOverlaySha256:hash(app),loaderOverlaySha256:hash(loader),node:process.version};
  program=replaceOnce(program,'await browser.close();',`fs.writeFileSync(${JSON.stringify(path.join(root,id+'.json'))},JSON.stringify({identity:${JSON.stringify(identity)},passed,failed,skipped,results,events},null,2));\nawait browser.close();`);
  const script=path.join(dest,'scripts/scenario44Diagnostic.ts');fs.writeFileSync(script,program);
  const started=new Date().toISOString();const run=spawnSync(process.execPath,['--import','tsx',script],{cwd:dest,encoding:'utf8',timeout:120000,env:{...process.env,PATH:path.dirname(process.execPath)+';'+process.env.PATH,GEMINI_API_KEY:''}});
  fs.writeFileSync(path.join(root,id+'.log'),(run.stdout||'')+(run.stderr||''));
  const entry={...identity,started,finished:new Date().toISOString(),overlayTestSha256:hash(program),exit:run.status,error:run.error?.message,expectedExit:mode==='old-held'?1:0};matrix.push(entry);fs.writeFileSync(path.join(root,'supplement-matrix.json'),JSON.stringify(matrix,null,2));console.log(JSON.stringify(entry));
 }}finally{fs.writeFileSync(appPath,originalApp);fs.writeFileSync(loaderPath,originalLoader);}
}
