import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
const root=path.dirname(process.argv[1]);
const source='C:/Users/HomePC/.codex/worktrees/body-parser-security/docmonstakrakin-version-sync';
const retained='C:/Users/HomePC/AppData/Local/Temp/codex-security-artifacts-26f85b591043c7b00003b9a0d81fdfdc25f5e49c587640d6578536eb69d42bbe/artifacts/scenario47/candidate/node_modules';
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
for(const [label,sha] of [['reviewed','a42586570869b8e19414f487840c7a8222079025'],['merged','46efc65d48c8e2057e500e3d8a805e650eff0c8c']]){
 const dest=path.join(root,label);if(fs.existsSync(dest))throw Error('Refuse existing clone');
 execFileSync('git',['clone','--no-hardlinks','--no-checkout',source,dest],{stdio:'inherit'});
 const git=(...a)=>execFileSync('git',['-C',dest,...a],{encoding:'utf8'}).trim();
 git('config','core.longpaths','true');git('config','core.autocrlf','false');git('checkout','--detach',sha);
 if(git('status','--porcelain'))throw Error('Not clean');
 fs.cpSync(retained,path.join(dest,'node_modules'),{recursive:true,dereference:true});
 const lock=JSON.parse(fs.readFileSync(path.join(dest,'package-lock.json'),'utf8')),mismatch=[];let checked=0;
 for(const [p,v] of Object.entries(lock.packages)){if(!p||!v.version)continue;const f=path.join(dest,p,'package.json');if(!fs.existsSync(f)){if(!v.optional)mismatch.push({p,missing:true});continue;}checked++;const actual=JSON.parse(fs.readFileSync(f,'utf8')).version;if(actual!==v.version)mismatch.push({p,expected:v.version,actual});}
 const record={label,commit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),node:process.version,os:os.release(),arch:os.arch(),retained,installationQualification:false,checked,mismatch,lockSha256:hash(path.join(dest,'package-lock.json')),testSha256:hash(path.join(dest,'scripts/testControlledDocVersionSync.ts')),tools:Object.fromEntries(['vite','playwright','typescript','tsx','express','body-parser'].map(p=>[p,JSON.parse(fs.readFileSync(path.join(dest,'node_modules',p,'package.json'),'utf8')).version]))};
 fs.writeFileSync(path.join(root,label+'-environment.json'),JSON.stringify(record,null,2));console.log(JSON.stringify(record));if(mismatch.length)throw Error('Dependency mismatch');
}
