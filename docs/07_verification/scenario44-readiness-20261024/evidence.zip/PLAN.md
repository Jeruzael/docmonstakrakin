# Scenario 44 bounded investigation (fixed before experiments)

Baseline master46efc65d48c8e2057e500e3d8a805e650eff0c8c; reviewed candidatea42586570869b8e19414f487840c7a8222079025. Both trees9a7a101e0d3c0543b83d2574e0e157d5c047ffec. Preserve failure40050545096/artifact12543337386; no workflow retry.

Use two fresh disposable clones, regular copies of the same retained dependencies (not installation qualification), Node22.23.3 and installed Chrome. No operator files, identities or services. API requests remain intercepted by existing fixtures. Instrument only disposable application copies with read-only event logging; restore before qualification. No state writes, certification forcing, timeout changes or fake successful snapshots.

Predetermined matrix: one run of each cell, no retry-until-green.
1. On both reviewed and merged trees: Scenario44 original immediate assertion while initial project response is held (expected assertion failure).
2. On both: proposed scenario-only readiness wait under that same held schedule, prove pending before release then execute complete original v120 -> list121 -> stale120 -> current121 contract.
3. On both: missing initial response; readiness must time out at existing8000ms.
4. On both: invalid initial stateVersion; readiness must time out at existing8000ms, error recorded.
5. On merged tree only: existing unchanged Scenarios47,48,49,50 under held initial response, demonstrate each existing readiness consumer waits then completes after release. No changes to these scenarios unless separately demonstrated missing precondition.

Inspect all50 test entries, inventory their initial requirements and later intentionally pending/empty/error/stale phases. Cases with workflow visibility/actionability waits are distinguished from metadata-only and source-contract checks. No global harness readiness wait.

Qualification after supported correction: uninstrumented focused44/47/48/49/50; complete50-entry version-sync; parser, enforced server, perimeter and server security suites; TypeScript; all four hosted CI jobs on exact signed candidate. Hosted complete regression, WBS/build and controlled-document jobs are mandatory. Local retained dependencies never imply clean Windows setup. Preserve every outcome including diagnostic infrastructure failures; additions to this matrix require a documented reason, not silent retry.

## Bounded diagnostic amendment, before supplemental runs

The reviewed-tree original-held cell failed at initial navigation, before the target assertion; all other reviewed controls reached their target. Permit exactly one additional reviewed original-held run to seek the target assertion, retaining the navigation failure regardless of outcome. Do not extend its8000ms bound.

Scenario49's planned release trigger at the current-report wait is unreachable while the earlier controlled-docs workspace wait correctly blocks on the held initial snapshot. Preserve that8000ms timeout as diagnostic-design evidence, not a runtime failure or successful full scenario. Permit exactly one additional49 run releasing at this first existing snapshot-dependent workspace wait; no test-source correction is indicated. No other repetition added.
